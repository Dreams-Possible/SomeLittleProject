#pragma once
#include"Platform/sp_sys.h"

//鼠标左键
void usb_mouse_key_r(u8 st);
//鼠标右键
void usb_mouse_key_l(u8 st);
//鼠标中键
void usb_mouse_key_m(u8 st);
//鼠标X轴移动
void usb_mouse_move_x(i8 x);
//鼠标Y轴移动
void usb_mouse_move_y(i8 y);
//鼠标滚动
void usb_mouse_move_r(i8 r);
//鼠标报告
void usb_mouse_report();