#pragma once

//头文件
#include"sp_sys.h"
#include<string.h>
#include<stdarg.h>
#include<stdio.h>

//CubeIDE中按如下配置
//启用串口
//启用TX和RX的DMA通道
//启用串口中断
//其余默认即可

//串口发送
void sp_uart_tx(char*data,...);
//串口直接发送
void sp_uart_tx_dir(u8*data,u16 len);
//串口接收
char*sp_uart_rx();
//串口直接接收
void sp_uart_rx_dir(u8**data,u16*len);
//串口超时接收
char*sp_uart_rx_time(u16 time);

//平台串口1发送
void sp_pl_uart1_tx(char*data,...);
//平台串口1直接发送
void sp_pl_uart1_tx_dir(u8*data,u16 len);
//平台串口1接收
char*sp_pl_uart1_rx();
//平台串口1直接接收
void sp_pl_uart1_rx_dir(u8**data,u16*len);
//平台串口1超时接收
char*sp_pl_uart1_rx_time(u16 time);

//平台串口2发送
void sp_pl_uart2_tx(char*data,...);
//平台串口2直接发送
void sp_pl_uart2_tx_dir(u8*data,u16 len);
//平台串口2接收
char*sp_pl_uart2_rx();
//平台串口2直接接收
void sp_pl_uart2_rx_dir(u8**data,u16*len);
//平台串口2超时接收
char*sp_pl_uart2_rx_time(u16 time);
