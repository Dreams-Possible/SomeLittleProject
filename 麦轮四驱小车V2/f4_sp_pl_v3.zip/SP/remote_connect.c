#include"remote_connect.h"

//远程系统线程属性
static osThreadId_t remote_system_thid=NULL;
static osThreadAttr_t remote_system_thattr=
{
    .name="remote_system",
    .stack_size=128*8,
    .priority=(osPriority_t)osPriorityNormal,
};

//远程系统初始化
void remote_system_init();
//远程系统
static void remote_system();

//远程系统初始化
void remote_system_init()
{
    //创建远程系统线程
    remote_system_thid=osThreadNew(remote_system,NULL,&remote_system_thattr);
}

//远程系统
static void remote_system()
{
    float x=0;
    float y=0;
    float a=0;
    while(1)
    {
        //离线时间
        static u16 offline_time=0;
        //平台串口1接收
        char*data=sp_pl_uart1_rx_time(10);
        if(data)
        {
            //校验包头
            if(data[0]==0xa5)
            {
                // sp_uart_tx("%s",data);
                x=(i8)data[1];
                y=(i8)data[2];
                a=(i8)data[3];

                // sp_uart_tx("x=%f,y=%f,a=%f\n",x,y,a);

                // sp_uart_tx("x=%f,y=%f\n",x,y);

                move_system_mohor(x*0.4);
                move_system_mover(y*0.4);
                direct_system_angle(a*2);

                // sp_uart_tx("rec\n");
            }
        }else
        {
            //离线自动停止
            ++offline_time;
            if(offline_time>100)
            {
                // sp_uart_tx("stop\n");
                move_system_mohor(0);
                move_system_mover(0);
                offline_time=0;
            }
        }
    }
}
