#include"sp_pl_encoder.h"

//定义
extern TIM_HandleTypeDef htim2;
#define encoder1_timer htim2
extern TIM_HandleTypeDef htim3;
#define encoder2_timer htim3
extern TIM_HandleTypeDef htim4;
#define encoder3_timer htim4
extern TIM_HandleTypeDef htim8;
#define encoder4_timer htim8

//编码器数据
typedef struct encoder_data_t
{
	float encoder1;
	float encoder2;
	float encoder3;
	float encoder4;
}encoder_data_t;
static encoder_data_t encoder_data={0};

//编码器1初始化
static void encoder1_init();
//编码器2初始化
static void encoder2_init();
//编码器3初始化
static void encoder3_init();
//编码器4初始化
static void encoder4_init();
//平台编码器初始化
void sp_pl_encoders_init();
//编码器1读取
static void encoder1_read();
//编码器2读取
static void encoder2_read();
//编码器3读
static void encoder3_read();
//编码器4读取
static void encoder4_read();
//平台编码器读取
void sp_pl_encoder_read(float*encoder1,float*encoder2,float*encoder3,float*encoder4);

//编码器1初始化
static void encoder1_init()
{
	HAL_TIM_Encoder_Start(&encoder1_timer,TIM_CHANNEL_ALL);
}

//编码器2初始化
static void encoder2_init()
{
	HAL_TIM_Encoder_Start(&encoder2_timer,TIM_CHANNEL_ALL);
}

//编码器3初始化
static void encoder3_init()
{
	HAL_TIM_Encoder_Start(&encoder3_timer,TIM_CHANNEL_ALL);
}

//编码器4初始化
static void encoder4_init()
{
	HAL_TIM_Encoder_Start(&encoder4_timer,TIM_CHANNEL_ALL);
}

//平台编码器初始化
void sp_pl_encoders_init()
{
	encoder1_init();
	encoder2_init();
	encoder3_init();
	encoder4_init();
}

//编码器1读取
static void encoder1_read()
{
	//检测
	encoder_data.encoder1=(i16)__HAL_TIM_GetCounter(&encoder1_timer);
	//重置
	__HAL_TIM_SetCounter(&encoder1_timer,0);
}

//编码器2读取
static void encoder2_read()
{
	//检测
	encoder_data.encoder2=(i16)__HAL_TIM_GetCounter(&encoder2_timer);
	//重置
	__HAL_TIM_SetCounter(&encoder2_timer,0);
}

//编码器3读取
static void encoder3_read()
{
	//检测
	encoder_data.encoder3=(i16)__HAL_TIM_GetCounter(&encoder3_timer);
	//重置
	__HAL_TIM_SetCounter(&encoder3_timer,0);
}

//编码器4读取
static void encoder4_read()
{
	//检测
	encoder_data.encoder4=(i16)__HAL_TIM_GetCounter(&encoder4_timer);
	//重置
	__HAL_TIM_SetCounter(&encoder4_timer,0);
}

//平台编码器读取
void sp_pl_encoder_read(float*encoder1,float*encoder2,float*encoder3,float*encoder4)
{
	encoder1_read();
	if(encoder1)
	{
		*encoder1=encoder_data.encoder1;
	}
	encoder2_read();
	if(encoder2)
	{
		*encoder2=encoder_data.encoder2;
	}
	encoder3_read();
	if(encoder3)
	{
		*encoder3=encoder_data.encoder3;
	}
	encoder4_read();
	if(encoder4)
	{
		*encoder4=encoder_data.encoder4;
	}
}
