#include"sp_app.h"
#include"platform/sp_pl_encoder.h"
#include"platform/sp_pl_motor.h"
#include"platform/sp_pl_uart.h"
#include"sport_system.h"
#include"remote_connect.h"
#include"atkms901m_driver.h"

//用户应用
void sp_app();

//用户应用
void sp_app()
{
	SP_LOG("init\n");

    //平台编码器初始化
    sp_pl_encoders_init();
    //平台电机初始化
    sp_pl_motor_init();

    //运动系统初始化
    sport_system_init();

    //远程系统初始化
    remote_system_init();
    
    SP_LOG("init ok\n");
    
    // while(1)
    // {
    //     osDelay(10);
        
    // }

    // while(1)
    // {
    //     //从串口输入
    //     u8*data=NULL;
    //     u16 len=0;
    //     //串口直接接收
    //     sp_uart_rx_dir(&data,&len);
        
    //     sp_uart_tx("len=%d\n",len);
    //     sp_uart_tx("data=%s\n",data);
    //     //串口直接发送
    //     sp_uart_tx_dir(data,len);
    //     osDelay(10);

    // }

    while(1)
    {
        // // //从串口输入
        // // u8*data=NULL;
        // // u16 len=0;
        // // //平台串口2直接接收
        // // sp_pl_uart2_rx_dir(&data,&len);
        // // //串口直接发送
        // // sp_uart_tx_dir(data,len);
        // float roll=0;
        // float pitch=0;
        // float yaw=0;
        // if(!atkms901m_read(&roll,&pitch,&yaw))
        // {
        //     //输出
        //     // sp_uart_tx("Roll:%.2f,Pitch:%.2f,Yaw:%.2f\n",roll,pitch,yaw);
        //     sp_uart_tx("data:%.2f,%.2f,%.2f\n",roll,pitch,yaw);
        // }
        // float angle=90;
        // direct_system_angle(angle);
        osDelay(100);
    }
    
}



// float speed=20;
// speed_system_set(speed,speed,speed,speed);
// float encoder1=0;
// float encoder2=0;
// float encoder3=0;
// float encoder4=0;
// // sp_pl_encoder_read(&encoder1,&encoder2,&encoder3,&encoder4);
// speed_system_read(&encoder1,&encoder2,&encoder3,&encoder4);
// SP_LOG("%f,%f,%f,%f",encoder1,encoder2,encoder3,encoder4);


// sport_system_mover(50);
// // sport_system_motur(50);
// osDelay(1000);
// sport_system_mover(-50);
// // sport_system_motur(-50);

// //串口接收
// while(1)
// {
//     char*data=sp_uart_rx();
//     SP_LOG("data=%s",data);
// }
