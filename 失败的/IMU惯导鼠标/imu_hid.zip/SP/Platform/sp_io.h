#pragma once

//头文件
#include"sp_sys.h"

//IO1设置
void sp_io1_set();
//IO1翻转
void sp_io1_tog();
//IO1读取
u8 sp_io1_read();
