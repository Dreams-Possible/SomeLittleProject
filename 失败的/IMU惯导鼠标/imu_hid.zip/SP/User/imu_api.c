#include"imu_api.h"
#include"icm_api.h"
#include"micro_imu_lib.h"

//距离结构体
typedef struct imu_dis_t
{
    float vx;
    float vy;
    float vz;
    float sx;
    float sy;
    float sz;
}imu_dis_t;
imu_dis_t imu_dis={0};

//初始化
void imu_api_init();
//解算数据
void imu_api_run();
//获取姿态角
void imu_api_get_attu(float*roll,float*pitch,float*yaw);
//获取绝对加速度
void imu_api_get_accel(float*aax,float*aay,float*aaz);
//获取速度
void imu_api_get_spd(float*vx,float*vy,float*vz);
//获取距离
void imu_api_get_dis(float*sx,float*sy,float*sz);

//解算句柄
MIL_Handle_t imu_handle={0};

//初始化
void imu_api_init()
{
    icm_init();
    mil_handle_init(&imu_handle);
}

//解算数据
void imu_api_run()
{
    float ax=0,ay=0,az=0;
    float gx=0,gy=0,gz=0;
    float curr_time=0;
    static float last_time=0;
    //读加速度
    if(icm_read_accel(&ax,&ay,&az))
    {
        return;
    }
    //读陀螺仪
    if(icm_read_gyro(&gx,&gy,&gz))
    {
        return;
    }
    //换算单位
    ax*=9.8;
    ay*=9.8;
    az*=9.8;
    gx*=0.01745;
    gy*=0.01745;
    gz*=0.01745;
    //读时间
    curr_time=sp_timer_get()/1000000.0;
    //解算数据
    mil_get_imu(&imu_handle,gx,gy,gz,ax,ay,az,curr_time);
    mil_while_run(&imu_handle);
    //积分加速度
    if(last_time==0)
    {
        last_time=curr_time;
        return;
    }
    float aax=0,aay=0,aaz=0;
    mil_get_aaccel(&imu_handle,&aax,&aay,&aaz);
    float dt=curr_time-last_time;
    //积分速度
    imu_dis.vx+=aax*dt;
    imu_dis.vy+=aay*dt;
    imu_dis.vz+=(aaz-9.8)*dt;
    //积分位移
    imu_dis.sx+=imu_dis.vx*dt;
    imu_dis.sy+=imu_dis.vy*dt;
    imu_dis.sz+=imu_dis.vz*dt;
    //速度衰减
    imu_dis.vx*=0.99;
    imu_dis.vy*=0.99;
    imu_dis.vz*=0.99;
    //备份时间
    last_time=curr_time;
}

//获取姿态角
void imu_api_get_attu(float*roll,float*pitch,float*yaw)
{
    mil_get_ang(&imu_handle,roll,pitch,yaw);
}

//获取绝对加速度
void imu_api_get_accel(float*aax,float*aay,float*aaz)
{
    mil_get_aaccel(&imu_handle,aax,aay,aaz);
}

//获取速度
void imu_api_get_spd(float*vx,float*vy,float*vz)
{
    if(vx)
    {
        *vx=imu_dis.vx;
    }
    if(vy)
    {
        *vy=imu_dis.vy;
    }
    if(vz)
    {
        *vz=imu_dis.vz;
    }
}

//获取距离
void imu_api_get_dis(float*sx,float*sy,float*sz)
{
    if(sx)
    {
        *sx=imu_dis.sx;
    }
    if(sy)
    {
        *sy=imu_dis.sy;
    }
    if(sz)
    {
        *sz=imu_dis.sz;
    }
}
