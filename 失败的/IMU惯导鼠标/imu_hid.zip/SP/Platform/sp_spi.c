#include"sp_spi.h"

//SPI1配置
extern SPI_HandleTypeDef hspi2;
#define SP_SPI1 hspi2

//SPI1片选
void sp_spi1_ns(u8 st);
//SPI1发送
void sp_spi1_tx(u8*data,u16 len);
//SPI1接收
void sp_spi1_rx(u8*data,u16 len);
//SPI1发送接收
void sp_spi1_txrx(u8*tx_data,u8*rx_data,u16 len);

//SPI1片选
void sp_spi1_ns(u8 st)
{
    if(st)
    {
        HAL_GPIO_WritePin(SP_SPI1_NSS1_GPIO_Port,SP_SPI1_NSS1_Pin,GPIO_PIN_SET);
    }else
    {
        HAL_GPIO_WritePin(SP_SPI1_NSS1_GPIO_Port,SP_SPI1_NSS1_Pin,GPIO_PIN_RESET);
    }
}

//SPI1发送
void sp_spi1_tx(u8*data,u16 len)
{
    // //等待发送空闲
    // while(SP_SPI1.State!=HAL_SPI_STATE_READY)
    // {
    //     //sp_uart1_tx("txbusy\n");
    //     osDelay(1);
    // }
    // //DMA发送
    // HAL_SPI_Transmit_DMA(&SP_SPI1,data,len);
    //DMA发送
    HAL_SPI_Transmit(&SP_SPI1,data,len,HAL_MAX_DELAY);
}

//SPI1接收
void sp_spi1_rx(u8*data,u16 len)
{
    //DMA接收
    // HAL_SPI_Receive_DMA(&SP_SPI1,data,len);
    // //等待接收空闲
    // while(SP_SPI1.State!=HAL_SPI_STATE_READY)
    // {
    //     //sp_uart1_tx("rxbusy\n");
    //     osDelay(1);
    // }
    HAL_SPI_Receive(&SP_SPI1,data,len,HAL_MAX_DELAY);
}

//SPI1发送接收
void sp_spi1_txrx(u8*tx_data,u8*rx_data,u16 len)
{
    // //等待发送空闲
    // while(SP_SPI1.State!=HAL_SPI_STATE_READY)
    // {
    //     osDelay(1);
    // }
    // //DMA发送接收
    // HAL_SPI_TransmitReceive_DMA(&SP_SPI1,tx_data,rx_data,len);
    // //等待接收空闲
    // while(SP_SPI1.State!=HAL_SPI_STATE_READY)
    // {
    //     osDelay(1);
    // }
    HAL_SPI_TransmitReceive(&SP_SPI1,tx_data,rx_data,len,HAL_MAX_DELAY);
}




