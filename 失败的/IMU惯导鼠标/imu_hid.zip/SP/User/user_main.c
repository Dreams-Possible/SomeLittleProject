#include"user_main.h"
#include"usb_mouse.h"
// #include"icm42688_driver.h"
// #include"icm45686_driver.h"
#include"icm_api.h"
#include"imu_api.h"
#include"Libsp/sp_libio.h"

// extern SPI_HandleTypeDef hspi2;

void user_main();

void user_main()
{
    sp_uart1_tx("user_main_load\n");
    // //定时器测试
    // while(1)
    // {
    //     // sp_uart1_tx("%lu\n",(u32)sp_timer_get());
    //     // osDelay(100);
    //     // sp_timer_delay(100);
    // }


    // //鼠标测试
    // u8 mov=10;
    // while(1)
    // {
    //     sp_uart1_tx("move\n");
    //     //鼠标X轴移动
    //     usb_mouse_move_x(mov);
    //     //鼠标Y轴移动
    //     usb_mouse_move_y(-mov);
    //     //鼠标报告
    //     usb_mouse_report();
    //     mov=-mov;
    //     osDelay(100);
    // }


    // //ICMAPI测试
    // icm_init();

    // float ax=0,ay=0,az=0;
    // float gx=0,gy=0,gz=0;
    // while(1)
    // {
    //     static u32 cnt=0;
    //     ++cnt;
    //     imu_api_run();
    //     if(cnt>1)
    //     {
    //         icm_read_accel(&ax,&ay,&az);
    //         icm_read_accel(&gx,&gy,&gz);
    //         cnt=0;
    //     }
    // }




    //IMU测试
    imu_api_init();
    float roll=0;
    float pitch=0;
    float yaw=0;
//    float sx=0,sy=0,sz=0;
//    float vx=0,vy=0,vz=0;
//    float aax=0,aay=0,aaz=0;
    while(1)
    {
        static u32 cnt=0;
        ++cnt;
        imu_api_run();
        if(cnt>10)
        {
            imu_api_get_attu(&roll,&pitch,&yaw);
            sp_uart1_tx("%d,%d,%d\n",(i16)(roll),(i16)(pitch),(i16)(yaw));
            // imu_api_get_accel(&aax,&aay,&aaz);
            // sp_uart1_tx("%d,%d,%d\n",(i16)(aax*100),(i16)(aay*100),(i16)(aaz*100));
            // imu_api_get_spd(&vx,&vy,&vz);
            // sp_uart1_tx("%d,%d,%d\n",(i16)(vx*100),(i16)(vy*100),(i16)(vz*100));
            // imu_api_get_dis(&sx,&sy,&sz);
            // sp_uart1_tx("%d,%d,%d\n",(i16)(sx*100),(i16)(sy*100),(i16)(sz*100));
            cnt=0;
        }
    }


    // //ICM测试
    // while(1)
    // {
    //     u8 reg= 0x72;
    //     uint8_t tx[2] = {reg | 0x80, 0x00};
    //     uint8_t rx[2]={0};

    //     sp_spi1_ns(0);
    //     // HAL_SPI_TransmitReceive(&hspi2, tx, rx, 2, HAL_MAX_DELAY);
    //     // HAL_SPI_Transmit(&hspi2, tx, 1, HAL_MAX_DELAY);
    //     // HAL_SPI_Transmit_IT(&hspi2, tx, 1);
    //     sp_spi1_tx(tx, 1);
    //     // HAL_SPI_Receive(&hspi2, rx, 1, HAL_MAX_DELAY);
    //     // HAL_SPI_Receive_IT(&hspi2, rx, 1);
    //     sp_spi1_rx(rx, 1);
    //     sp_spi1_ns(1);

    //     // uint8_t value = rx[1]; // 这才是寄存器值
    //     uint8_t value = rx[0]; // 这才是寄存器值
    //     sp_uart1_tx("ICM ID %02X\n", value);
    // }



    // //W25Qxx测试
    // while(1)
    // {
    //     uint8_t cmd = 0x9F;
    //     uint8_t recv[3] = {0};

    //     sp_spi1_ns(0);
    //     HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    //     HAL_SPI_Receive(&hspi1, recv, 3, HAL_MAX_DELAY);
    //     sp_spi1_ns(1);
    //     sp_uart1_tx("recv: %02X %02X %02X\n", recv[0], recv[1], recv[2]);
    //     osDelay(100);
    // }


    // // ICMAPI测试
    // icm_init();
    // // 初始化
    // float temp = 0;
    // float ax = 0, ay = 0, az = 0;
    // float gx = 0, gy = 0, gz = 0;
    // char buf1[16]={0}, buf2[16]={0}, buf3[16]={0};
    // char buf_temp[16];
    // while (1)
    // {
    //     temp = icm_read_temp();
    //     sp_libio_pfs2(temp, buf_temp, sizeof(buf_temp));
    //     sp_uart1_tx("Temp: %s C\n", buf_temp);

    //     icm_read_accel(&ax, &ay, &az);
    //     sp_libio_pfs2(ax, buf1, sizeof(buf1));
    //     sp_libio_pfs2(ay, buf2, sizeof(buf2));
    //     sp_libio_pfs2(az, buf3, sizeof(buf3));
    //     sp_uart1_tx("Accel: X=%s Y=%s Z=%s g\n", buf1, buf2, buf3);

    //     icm_read_gyro(&gx, &gy, &gz);
    //     sp_libio_pfs2(gx, buf1, sizeof(buf1));
    //     sp_libio_pfs2(gy, buf2, sizeof(buf2));
    //     sp_libio_pfs2(gz, buf3, sizeof(buf3));
    //     sp_uart1_tx("Gyro: X=%s Y=%s Z=%s dps\n", buf1, buf2, buf3);

    //     osDelay(10);
    // }


    // //ICM42688测试
    // //初始化
    // int16_t temp=0;
    // int16_t ax=0;
    // int16_t ay=0;
    // int16_t az=0;
    // int16_t gx=0;
    // int16_t gy=0;
    // int16_t gz=0;
    // while(icm42688_init())
    // {
    //     sp_uart1_tx("icm42688_init_err\n");
    //     osDelay(1000);
    // }
    // while(1)
    // {
    //     // 读温度
    //     if(icm42688_read_temp(&temp) == 0)
    //     {
    //         sp_uart1_tx("Temp: %d C\n", (i16)(temp / 132.48 + 25.0)); // 根据官方换算公式
    //     }

    //     // 读加速度
    //     if(icm42688_read_accel(&ax, &ay, &az) == 0)
    //     {
    //         sp_uart1_tx("Accel: X=%d Y=%d Z=%d\n", (i16)(ax/32768*16), (i16)(ay/32768*16), (i16)(az/32768*16));
    //     }

    //     // 读陀螺仪
    //     if(icm42688_read_gyro(&gx, &gy, &gz) == 0)
    //     {
    //         sp_uart1_tx("Gyro: X=%d Y=%d Z=%d\n", (i16)(gx/32768*2000), (i16)(gy/32768*2000), (i16)(gz/32768*2000));
    //     }

    //     // 延时一会（根据你的平台决定用HAL_Delay还是rtos延时）
    //     osDelay(100);
    // }




}

