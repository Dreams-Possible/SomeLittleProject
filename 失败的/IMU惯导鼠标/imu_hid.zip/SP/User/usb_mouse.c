#include"usb_mouse.h"
#include"usb_device.h"
#include"usbd_hid.h"

//USB鼠标句柄
extern USBD_HandleTypeDef hUsbDeviceFS;


//鼠标数据
//[0]：bit0左键，bit1右键，bit2中键
//[1]：X轴移动（-127~127）
//[2]：Y轴移动（-127~127）
//[3]：滚动（-127~127）
i8 mouse_data[4]={0};


//鼠标左键
void usb_mouse_key_r(u8 st);
//鼠标右键
void usb_mouse_key_l(u8 st);
//鼠标中键
void usb_mouse_key_m(u8 st);
//鼠标X轴移动
void usb_mouse_move_x(i8 x);
//鼠标Y轴移动
void usb_mouse_move_y(i8 y);
//鼠标滚动
void usb_mouse_move_r(i8 r);
//鼠标报告
void usb_mouse_report();




//鼠标左键
void usb_mouse_key_r(u8 st)
{
  if(st)
  {
    mouse_data[0]|=0x01;
  }
  else
  {
    mouse_data[0]&=~0x01;
  }
}

//鼠标右键
void usb_mouse_key_l(u8 st)
{
  if(st)
  {
    mouse_data[0]|=0x02;
  }
  else
  {
    mouse_data[0]&=~0x02;
  }
}

//鼠标中键
void usb_mouse_key_m(u8 st)
{
  if(st)
  {
    mouse_data[0]|=0x04;
  }
  else
  {
    mouse_data[0]&=~0x04;
  }
}

//鼠标X轴移动
void usb_mouse_move_x(i8 x)
{
  mouse_data[1]=x;
}

//鼠标Y轴移动
void usb_mouse_move_y(i8 y)
{
  mouse_data[2]=y;
}

//鼠标滚动
void usb_mouse_move_r(i8 r)
{
  mouse_data[1]=r;
}

//鼠标报告
void usb_mouse_report()
{
  USBD_HID_SendReport(&hUsbDeviceFS,(u8*)mouse_data,sizeof(mouse_data));
  memset(mouse_data,0,sizeof(mouse_data));
}
