#include"sp_pl_motor.h"

//定义
extern TIM_HandleTypeDef htim1;
#define MOTOR_TIMER htim1
#define MOTOR1_TMCH TIM_CHANNEL_1
#define MOTOR2_TMCH TIM_CHANNEL_2
#define MOTOR3_TMCH TIM_CHANNEL_3
#define MOTOR4_TMCH TIM_CHANNEL_4
#define FULL_TIMER_COUNTER 65535
#define AIN1_1(x) HAL_GPIO_WritePin(AIN1_1_GPIO_Port,AIN1_1_Pin,(GPIO_PinState)(x))
#define AIN2_1(x) HAL_GPIO_WritePin(AIN2_1_GPIO_Port,AIN2_1_Pin,(GPIO_PinState)(x))
#define BIN1_1(x) HAL_GPIO_WritePin(BIN1_1_GPIO_Port,BIN1_1_Pin,(GPIO_PinState)(x))
#define BIN2_1(x) HAL_GPIO_WritePin(BIN2_1_GPIO_Port,BIN2_1_Pin,(GPIO_PinState)(x))
#define AIN1_2(x) HAL_GPIO_WritePin(AIN1_2_GPIO_Port,AIN1_2_Pin,(GPIO_PinState)(x))
#define AIN2_2(x) HAL_GPIO_WritePin(AIN2_2_GPIO_Port,AIN2_2_Pin,(GPIO_PinState)(x))
#define BIN1_2(x) HAL_GPIO_WritePin(BIN1_2_GPIO_Port,BIN1_2_Pin,(GPIO_PinState)(x))
#define BIN2_2(x) HAL_GPIO_WritePin(BIN2_2_GPIO_Port,BIN2_2_Pin,(GPIO_PinState)(x))

//电机数据
typedef struct motor_data_t
{
	float motor1;
	float motor2;
	float motor3;
	float motor4;
}motor_data_t;
static motor_data_t motor_data={0};

//电机1初始化
static void motor1_init();
//电机2初始化
static void motor2_init();
//电机3初始化
static void motor3_init();
//电机4初始化
static void motor4_init();
//平台电机初始化
void sp_pl_motor_init();
//电机1设置
static void motor1_set();
//电机2设置
static void motor2_set();
//电机3设置
static void motor3_set();
//电机4设置
static void motor4_set();
//平台电机设置
void sp_pl_motor_set(float motor1,float motor2,float motor3,float motor4);

//电机1初始化
static void motor1_init()
{
	HAL_TIM_PWM_Start(&MOTOR_TIMER,MOTOR1_TMCH);
}
//电机2初始化
static void motor2_init()
{
	HAL_TIM_PWM_Start(&MOTOR_TIMER,MOTOR2_TMCH);
}
//电机3初始化
static void motor3_init()
{
	HAL_TIM_PWM_Start(&MOTOR_TIMER,MOTOR3_TMCH);
}
//电机4初始化
static void motor4_init()
{
	HAL_TIM_PWM_Start(&MOTOR_TIMER,MOTOR4_TMCH);
}

//平台电机初始化
void sp_pl_motor_init()
{
	motor1_init();
	motor2_init();
	motor3_init();
	motor4_init();
}

//电机1设置
static void motor1_set()
{
	//限制速度
	if(motor_data.motor1>100)
	{
		motor_data.motor1=100;
	}else
	if(motor_data.motor1<-100)
	{
		motor_data.motor1=-100;
	}
	//设置速度
	if(motor_data.motor1>=0)
	{
		AIN1_1(1);
		AIN2_1(0);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR1_TMCH,(i16)(motor_data.motor1/100*FULL_TIMER_COUNTER));
	}else
	if(motor_data.motor1<=0)
	{
		AIN1_1(0);
		AIN2_1(1);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR1_TMCH,(i16)(-motor_data.motor1/100*FULL_TIMER_COUNTER));
	}
}

//电机2设置
static void motor2_set()
{
	//限制速度
	if(motor_data.motor2>100)
	{
		motor_data.motor2=100;
	}else
	if(motor_data.motor2<-100)
	{
		motor_data.motor2=-100;
	}
	//设置速度
	if(motor_data.motor2>=0)
	{
		BIN1_1(1);
		BIN2_1(0);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR2_TMCH,(i16)(motor_data.motor2/100*FULL_TIMER_COUNTER));
	}else
	if(motor_data.motor2<=0)
	{
		BIN1_1(0);
		BIN2_1(1);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR2_TMCH,(i16)(-motor_data.motor2/100*FULL_TIMER_COUNTER));
	}
}

//电机3设置
static void motor3_set()
{
	//限制速度
	if(motor_data.motor3>100)
	{
		motor_data.motor3=100;
	}else
	if(motor_data.motor3<-100)
	{
		motor_data.motor3=-100;
	}
	//设置速度
	if(motor_data.motor3>=0)
	{
		AIN1_2(1);
		AIN2_2(0);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR3_TMCH,(i16)(motor_data.motor3/100*FULL_TIMER_COUNTER));
	}else
	if(motor_data.motor3<=0)
	{
		AIN1_2(0);
		AIN2_2(1);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR3_TMCH,(i16)(-motor_data.motor3/100*FULL_TIMER_COUNTER));
	}
}

//电机4设置
static void motor4_set()
{
	//限制速度
	if(motor_data.motor4>100)
	{
		motor_data.motor4=100;
	}else
	if(motor_data.motor4<-100)
	{
		motor_data.motor4=-100;
	}
	//设置速度
	if(motor_data.motor4>=0)
	{
		BIN1_2(1);
		BIN2_2(0);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR4_TMCH,(i16)(motor_data.motor4/100*FULL_TIMER_COUNTER));
	}else
	if(motor_data.motor4<=0)
	{
		BIN1_2(0);
		BIN2_2(1);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR4_TMCH,(i16)(-motor_data.motor4/100*FULL_TIMER_COUNTER));
	}
}

//平台电机设置
void sp_pl_motor_set(float motor1,float motor2,float motor3,float motor4)
{
	motor_data.motor1=motor1;
	motor1_set();

	motor_data.motor2=motor2;
	motor2_set();

	motor_data.motor3=motor3;
	motor3_set();

	motor_data.motor4=motor4;
	motor4_set();
}
