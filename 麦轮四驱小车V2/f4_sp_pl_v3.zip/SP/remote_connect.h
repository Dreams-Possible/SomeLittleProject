#pragma once

//头文件
#include"sp_sys.h"
#include"sport_system.h"

//远程系统初始化
void remote_system_init();
