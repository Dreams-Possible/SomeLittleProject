#pragma once

//头文件
#include"sp_sys.h"

//SPI1片选
void sp_spi1_ns(u8 st);
//SPI1发送
void sp_spi1_tx(u8*data,u16 len);
//SPI1接收
void sp_spi1_rx(u8*data,u16 len);
//SPI1发送接收
void sp_spi1_txrx(u8*tx_data,u8*rx_data,u16 len);
