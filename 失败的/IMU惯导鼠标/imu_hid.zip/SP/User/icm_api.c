#include"icm_api.h"
#include"icm45686_driver.h"
#include<math.h>
// #include"Libsp/sp_libio.h"

//初始化
void icm_init();
//读温度
float icm_read_temp();
//读加速度
u8 icm_read_accel(float*ax,float*ay,float*az);
//读陀螺仪
u8 icm_read_gyro(float*gx,float*gy,float*gz);

//初始化
void icm_init()
{
    while(icm45686_init())
    {
        sp_uart1_tx("icm_init_err\n");
        osDelay(100);
    }
}

//读温度
float icm_read_temp()
{
    int16_t temp=0;
    if(!icm45686_read_temp(&temp))
    {
        return (float)(temp/128.0+25);
    }
    return 0.0;
}
//读加速度
u8 icm_read_accel(float*ax,float*ay,float*az)
{
    int16_t accel_x=0;
    int16_t accel_y=0;
    int16_t accel_z=0;
    if(!icm45686_read_accel(&accel_x,&accel_y,&accel_z))
    {
        if(ax)*ax=(float)(accel_x/1024.0);
        if(ay)*ay=(float)(accel_y/1024.0);
        if(az)*az=(float)(accel_z/1024.0);
    }
    return 0;
    // sp_uart1_tx("ax=%s,",sp_libio_pf2(*ax));
    // sp_uart1_tx("ay=%s,",sp_libio_pf2(*ay));
    // sp_uart1_tx("az=%s,",sp_libio_pf2(*az));
    // sp_uart1_tx("\n");
}
//读陀螺仪
u8 icm_read_gyro(float*gx,float*gy,float*gz)
{
    int16_t gyro_x=0;
    int16_t gyro_y=0;
    int16_t gyro_z=0;
    if(!icm45686_read_gyro(&gyro_x,&gyro_y,&gyro_z))
    {
        if(fabs(gyro_x)>2000&&fabs(gyro_y)>2000&&fabs(gyro_z)>2000)
        {
            return 1;
        }
        if(gx)*gx=(float)(gyro_x/8.2);
        if(gy)*gy=(float)(gyro_y/8.2);
        if(gz)*gz=(float)(gyro_z/8.2);
    }
    return 0;
    // sp_uart1_tx("gx=%s,",sp_libio_pf2(*gx));
    // sp_uart1_tx("gy=%s,",sp_libio_pf2(*gy));
    // sp_uart1_tx("gz=%s,",sp_libio_pf2(*gz));
    // sp_uart1_tx("\n");
}
