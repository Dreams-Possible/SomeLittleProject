#pragma once

//头文件
#include"sp_sys.h"
#include"platform/sp_pl_motor.h"
#include"platform/sp_pl_encoder.h"
#include<math.h>
#include"atkms901m_driver.h"

// //运动系统数据结构
// typedef struct sport_system_data_t
// {
//     u8 speed_state;
//     u8 direct_state;
//     float direct_yaw;
//     float speed_ver;
//     float speed_hor;
// }sport_system_data_t;
// //运动系统数据
// extern sport_system_data_t sport_system_data;

//运动系统初始化
void sport_system_init();
//速度系统设置
void speed_system_set(float speed_1,float speed_2,float speed_3,float speed_4);
//速度系统读取
void speed_system_read(float*speed_1,float*speed_2,float*speed_3,float*speed_4);
//移动系统前后移动（前正后负）
void move_system_mover(float speed);
//移动系统左右移动（左正右负）
void move_system_mohor(float speed);
//方向系统设置角度
void direct_system_angle(float angle);