#include"sp_sys.h"

//初始化应用
void sp_sys_init();
//应用
static void sys_main(void*argument);

//任务句柄
static osThreadId_t appTaskHandle;
static osThreadAttr_t appTask_attributes=
{
    .name="appTask",
    .stack_size=128*32,
    .priority=(osPriority_t)osPriorityNormal,
};

//初始化应用
void sp_sys_init()
{
    appTaskHandle=osThreadNew(sys_main,NULL,&appTask_attributes);
}

//转到用户应用
static void sys_main(void*argument)
{
    sp_app();
    osThreadExit();
}
