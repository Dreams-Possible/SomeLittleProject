#include"sp_libio.h"

//浮点数转换（保留两位小数）
char*sp_libio_pf2(float value);
//浮点数转换（保留两位小数，安全版本）
void sp_libio_pfs2(float value, char *buf, size_t size);

//浮点数转换（保留两位小数）
char*sp_libio_pf2(float value)
{
    static char buf[16]={0};
    memset(buf,0,sizeof(buf));
    int32_t int_part = (int32_t)value;
    float diff = value - (float)int_part;
    if(diff < 0)
    {
        diff = -diff;
    }
    int32_t frac_part = (int32_t)(diff * 100);
    snprintf(buf, sizeof(buf), "%d.%02d", (int)int_part, (int)frac_part);
    return buf;
}

//浮点数转换（保留两位小数，安全版本）
void sp_libio_pfs2(float value, char *buf, size_t size)
{
    if (buf == NULL || size == 0)
    {
        return;
    }
    int32_t int_part = (int32_t)value;
    float diff = value - (float)int_part;
    if (diff < 0)
    {
        diff = -diff;
    }
    int32_t frac_part = (int32_t)(diff * 100);
    snprintf(buf, size, "%d.%02d", (int)int_part, (int)frac_part);
}
