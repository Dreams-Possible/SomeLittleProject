#pragma once

//头文件
#include<stdint.h>
#include<stdio.h>
#include<string.h>

//浮点数转换（保留两位小数）
char*sp_libio_pf2(float value);
//浮点数转换（保留两位小数，安全版本）
void sp_libio_pfs2(float value, char *buf, size_t size);
