#pragma once
#include"sp_sys.h"

//CubeIDE中按如下配置
//设置定时器为编码器模式
//其余默认即可

//平台编码器初始化
void sp_pl_encoders_init();
//平台编码器读取
void sp_pl_encoder_read(float*encoder1,float*encoder2,float*encoder3,float*encoder4);
