#include"sp_io.h"

//IO1设置
void sp_io1_set();
//IO1翻转
void sp_io1_tog();
//IO1读取
u8 sp_io1_read();

//IO1设置
void sp_io1_set()
{
    HAL_GPIO_WritePin(SP_IO1_GPIO_Port,SP_IO1_Pin,GPIO_PIN_SET);
}

//IO1翻转
void sp_io1_tog()
{
    HAL_GPIO_TogglePin(SP_IO1_GPIO_Port,SP_IO1_Pin);
}

//IO1读取
u8 sp_io1_read()
{
    return (u8)HAL_GPIO_ReadPin(SP_IO1_GPIO_Port,SP_IO1_Pin);
}
