#include"sport_system.h"

//轮胎位置
//AB13
//BA24

//定义
#define MAX_SPEED 100
#define INV_SPEED 10

//速度系统数据结构
typedef struct speed_system_data_t
{
    //实时速度
    float real_1;
    float real_2;
    float real_3;
    float real_4;
    //目标速度
    float target_1;
    float target_2;
    float target_3;
    float target_4;
    //设置速度
    float set_1;
    float set_2;
    float set_3;
    float set_4;
}speed_system_data_t;
//速度系统数据
static speed_system_data_t speed_system_data;

//速度系统线程属性
static osThreadId_t speed_system_thid=NULL;
static osThreadAttr_t speed_system_thattr=
{
    .name="speed_system",
    .stack_size=128*12,
    .priority=(osPriority_t)osPriorityNormal,
};


//移动系统数据结构
typedef struct move_system_data_t
{
    float speed_ver;
    float speed_hor;
}move_system_data_t;
//移动系统数据
move_system_data_t move_system_data={0};

//移动系统线程属性
static osThreadId_t move_system_thid=NULL;
static osThreadAttr_t move_system_thattr=
{
    .name="move_system",
    .stack_size=128*12,
    .priority=(osPriority_t)osPriorityNormal,
};


//方向系统数据结构
typedef struct direct_system_data_t
{
    float real_angle;
    float target_angle;
    float set_angle;
}direct_system_data_t;
//方向系统数据
direct_system_data_t direct_system_data={0};

//方向系统线程属性
static osThreadId_t direct_system_thid=NULL;
static osThreadAttr_t direct_system_thattr=
{
    .name="direct_system",
    .stack_size=128*12,
    .priority=(osPriority_t)osPriorityNormal,
};

// //运动系统数据结构
// typedef struct sport_system_data_t
// {
//     float speed_1;
//     float speed_2;
//     float speed_3;
//     float speed_4;
//     float angle;
// }sport_system_data_t;
// //运动系统数据
// sport_system_data_t sport_system_data={0};

// //运动系统线程属性
// static osThreadId_t sport_system_thid=NULL;
// static osThreadAttr_t sport_system_thattr=
// {
//     .name="sport_system",
//     .stack_size=128*12,
//     .priority=(osPriority_t)osPriorityNormal,
// };


//运动系统初始化
void sport_system_init();
//速度系统
static void speed_system(void*p);
//速度系统设置
void speed_system_set(float speed_1,float speed_2,float speed_3,float speed_4);
//速度系统读取
void speed_system_read(float*speed_1,float*speed_2,float*speed_3,float*speed_4);
//移动系统
static void move_system(void*p);
//移动系统前后移动（前正后负）
void move_system_mover(float speed);
//移动系统左右移动（左正右负）
void move_system_mohor(float speed);
//方向系统
static void direct_system(void*p);
//方向系统设置角度
void direct_system_angle(float angle);
// //运动系统
// static void sport_system(void*p);







//运动系统初始化
void sport_system_init()
{
    //创建速度系统线程
    speed_system_thid=osThreadNew(speed_system,NULL,&speed_system_thattr);
    //创建移动系统线程
    move_system_thid=osThreadNew(move_system,NULL,&move_system_thattr);
    //创建方向系统线程
    direct_system_thid=osThreadNew(direct_system,NULL,&direct_system_thattr);
    // //创建运动系统线程
    // sport_system_thid=osThreadNew(sport_system,NULL,&sport_system_thattr);
}

//速度系统
static void speed_system(void*p)
{
    //PID参数
    float k_p=0.12;
    //PID调整速度
    while(1)
    {
        //读取实时速度
        float encoder1=0;
        float encoder2=0;
        float encoder3=0;
        float encoder4=0;
        sp_pl_encoder_read(&encoder1,&encoder2,&encoder3,&encoder4);
        // SP_LOG("%.2f,%.2f,%.2f,%.2f,",encoder1,encoder2,encoder3,encoder4);
        //滤波
        speed_system_data.real_1=encoder1*0.8+speed_system_data.real_1*0.2;
        speed_system_data.real_2=encoder2*0.8+speed_system_data.real_2*0.2;
        speed_system_data.real_3=-encoder3*0.8+speed_system_data.real_3*0.2;
        speed_system_data.real_4=-encoder4*0.8+speed_system_data.real_4*0.2;
        //计算误差
        float e_1=speed_system_data.target_1-speed_system_data.real_1;
        float e_2=speed_system_data.target_2-speed_system_data.real_2;
        float e_3=speed_system_data.target_3-speed_system_data.real_3;
        float e_4=speed_system_data.target_4-speed_system_data.real_4;
        //PID调整
        speed_system_data.set_1+=k_p*e_1;
        speed_system_data.set_2+=k_p*e_2;
        speed_system_data.set_3+=k_p*e_3;
        speed_system_data.set_4+=k_p*e_4;
        //限位
        if(speed_system_data.set_1>MAX_SPEED)
        {
            speed_system_data.set_1=MAX_SPEED;
        }
        if(speed_system_data.set_1<-MAX_SPEED)
        {
            speed_system_data.set_1=-MAX_SPEED;
        }
        if(speed_system_data.set_2>MAX_SPEED)
        {
            speed_system_data.set_2=MAX_SPEED;
        }
        if(speed_system_data.set_2<-MAX_SPEED)
        {
            speed_system_data.set_2=-MAX_SPEED;
        }
        if(speed_system_data.set_3>MAX_SPEED)
        {
            speed_system_data.set_3=MAX_SPEED;
        }
        if(speed_system_data.set_3<-MAX_SPEED)
        {
            speed_system_data.set_3=-MAX_SPEED;
        }
        if(speed_system_data.set_4>MAX_SPEED)
        {
            speed_system_data.set_4=MAX_SPEED;
        }
        if(speed_system_data.set_4<-MAX_SPEED)
        {
            speed_system_data.set_4=-MAX_SPEED;
        }
        //低速停止
        static u16 set1_low_count=0;
        if(fabs(speed_system_data.set_1)<INV_SPEED)
        {
            ++set1_low_count;
            if(set1_low_count>100)
            {
                speed_system_data.set_1=0;
                set1_low_count=0;
            }
        }
        static u16 set2_low_count=0;
        if(fabs(speed_system_data.set_2)<INV_SPEED)
        {
            ++set2_low_count;
            if(set2_low_count>100)
            {
                speed_system_data.set_2=0;
                set2_low_count=0;
            }
        }
        static u16 set3_low_count=0;
        if(fabs(speed_system_data.set_3)<INV_SPEED)
        {
            ++set3_low_count;
            if(set3_low_count>100)
            {
                speed_system_data.set_3=0;
                set3_low_count=0;
            }
        }
        static u16 set4_low_count=0;
        if(fabs(speed_system_data.set_4)<INV_SPEED)
        {
            ++set4_low_count;
            if(set4_low_count>100)
            {
                speed_system_data.set_4=0;
                set4_low_count=0;
            }
        }
        //设置目标速度
        // sp_uart_tx("%.2f,%.2f,%.2f,%.2f\n",-speed_system_data.set_1,-speed_system_data.set_2,speed_system_data.set_3,speed_system_data.set_4);
        sp_pl_motor_set(-speed_system_data.set_1,-speed_system_data.set_2,speed_system_data.set_3,speed_system_data.set_4);
        //等待下个周期
        osDelay(10);
    }
}

//速度系统设置
void speed_system_set(float speed_1,float speed_2,float speed_3,float speed_4)
{
    if(speed_1>MAX_SPEED)
    {
        speed_1=MAX_SPEED;
    }
    if(speed_1<-MAX_SPEED)
    {
        speed_1=-MAX_SPEED;
    }
    if(speed_2>MAX_SPEED)
    {
        speed_2=MAX_SPEED;
    }
    if(speed_2<-MAX_SPEED)
    {
        speed_2=-MAX_SPEED;
    }
    if(speed_3>MAX_SPEED)
    {
        speed_3=MAX_SPEED;
    }
    if(speed_3<-MAX_SPEED)
    {
        speed_3=-MAX_SPEED;
    }
    if(speed_4>MAX_SPEED)
    {
        speed_4=MAX_SPEED;
    }
    if(speed_4<-MAX_SPEED)
    {
        speed_4=-MAX_SPEED;
    }
    speed_system_data.target_1=speed_1;
    speed_system_data.target_2=speed_2;
    speed_system_data.target_3=speed_3;
    speed_system_data.target_4=speed_4;
    // sp_uart_tx("%.2f,%.2f,%.2f,%.2f\n",speed_1,speed_2,speed_3,speed_4);
}

//速度系统读取
void speed_system_read(float*speed_1,float*speed_2,float*speed_3,float*speed_4)
{
    if(speed_1)
	{
		*speed_1=speed_system_data.real_1;
	}
	if(speed_2)
	{
		*speed_2=speed_system_data.real_2;
	}
	if(speed_3)
	{
		*speed_3=speed_system_data.real_3;
	}
	if(speed_4)
	{
		*speed_4=speed_system_data.real_4;
	}
}


//移动系统
static void move_system(void*p)
{
    while(1)
    {
        // speed_system_set(move_system_data.speed_ver+move_system_data.speed_hor,move_system_data.speed_ver-move_system_data.speed_hor,move_system_data.speed_ver+move_system_data.speed_hor,move_system_data.speed_ver-move_system_data.speed_hor);
        speed_system_set(move_system_data.speed_ver+move_system_data.speed_hor-direct_system_data.set_angle,move_system_data.speed_ver-move_system_data.speed_hor-direct_system_data.set_angle,move_system_data.speed_ver+move_system_data.speed_hor+direct_system_data.set_angle,move_system_data.speed_ver-move_system_data.speed_hor+direct_system_data.set_angle);
        //等待下个周期
        osDelay(10);
    }
}

//移动系统前后移动（前正后负）
void move_system_mover(float speed)
{
    move_system_data.speed_ver=speed;
    // speed_system_set(speed,speed,speed,speed);
}

//移动系统左右移动（左正右负）
void move_system_mohor(float speed)
{
    move_system_data.speed_hor=speed;
    // speed_system_set(speed,-speed,speed,-speed);
}


//方向系统
static void direct_system(void*p)
{
    //PID参数
    float k_p=1.2;
    while(1)
    {
        //读取实时角度
        float roll=0;
        float pitch=0;
        float yaw=0;
        if(!atkms901m_read(&roll,&pitch,&yaw))
        {
            //输出
            // sp_uart_tx("data:%.2f,%.2f,%.2f\n",roll,pitch,yaw);
            direct_system_data.real_angle=yaw;
        }
        //计算误差
        float ang_e=(direct_system_data.target_angle-direct_system_data.real_angle);
        //处理临界角度
        if(ang_e<-180)
        {
            ang_e+=360;
        }
        if(ang_e>180)
        {
            ang_e-=360;
        }
        // sp_uart_tx("e_1:%.2f\n",e_1);
        //调整角度
        direct_system_data.set_angle=k_p*ang_e;
        // speed_system_set(-e_1,-e_1,e_1,e_1);
        //等待下个周期
        osDelay(10);
    }
}    

//方向系统设置角度
void direct_system_angle(float angle)
{
    //限位
    if(angle>179)
    {
        angle=179;
    }
    if(angle<-179)
    {
        angle=-179;
    }
    direct_system_data.target_angle=angle;
}


// //运动系统
// static void sport_system(void*p)
// {
//     while(1)
//     {
//         //设置目标速度
//         // sp_uart_tx("%.2f,%.2f,%.2f,%.2f\n",-speed_system_data.set_1-direct_system_data.set_angle,-speed_system_data.set_2-direct_system_data.set_angle,speed_system_data.set_3+direct_system_data.set_angle,speed_system_data.set_4+direct_system_data.set_angle);
//         // sp_pl_motor_set(-speed_system_data.set_1-direct_system_data.set_angle,-speed_system_data.set_2-direct_system_data.set_angle,speed_system_data.set_3+direct_system_data.set_angle,speed_system_data.set_4+direct_system_data.set_angle);
//         //等待下个周期
//         osDelay(10);
//     }    
// }    
        
