#pragma once

//头文件
#include"sp_sys.h"

//CubeIDE中按如下配置
//启用定时器
//预分频系数按照主频设置
//时基单位为1微妙即可
//其余默认即可

//定时器使能
void sp_timer_init();
//定时器中断
void sp_timer_int(TIM_HandleTypeDef*htim);
//获取定时器计数（时基微秒）
u32 sp_timer_get();
//定时器延时（时基微秒）
void sp_timer_delay(u32 us);
//定时器复位
void sp_timer_reset();
