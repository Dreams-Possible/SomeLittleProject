#include"sp_app.h"
#include<math.h>

//用户应用
void sp_app();

//用户应用
void sp_app()
{
	SP_LOG("sp_app_load\n");

    
    while(1)
    {
        sp_uart_tx("start\n");
        //从串口输入
        u8*data=NULL;
        u16 len=0;
        // //串口接收
        // data=sp_uart_rx();
        //串口直接接收
        sp_uart_rx_dir(&data,&len);
        // //串口发送
        // sp_uart_tx(data);
        //串口直接发送
        sp_uart_tx_dir(data,len);
        osDelay(10);
    }


}
