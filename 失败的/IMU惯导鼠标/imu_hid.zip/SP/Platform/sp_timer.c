#include"sp_timer.h"

//定时器配置
extern TIM_HandleTypeDef htim3;
#define SP_TIMER htim3
#define TIMER_WIDE 16
volatile u32 timer_ext_count=0;//定时器扩展计数

//定时器使能
void sp_timer_init();
//定时器中断
void sp_timer_int(TIM_HandleTypeDef*htim);
//获取定时器计数（时基微秒）
u32 sp_timer_get();
//定时器延时（时基微秒）
void sp_timer_delay(u32 us);
//定时器复位
void sp_timer_reset();

//定时器使能
void sp_timer_init()
{
    HAL_TIM_Base_Start_IT(&SP_TIMER);
}

//定时器中断
void sp_timer_int(TIM_HandleTypeDef*htim)
{
    if(htim->Instance==SP_TIMER.Instance)
    {
        ++timer_ext_count;
    }
}

//获取定时器计数（时基微秒）
u32 sp_timer_get()
{
    return ((timer_ext_count<<TIMER_WIDE)|(SP_TIMER.Instance->CNT));
}

//定时器延时（时基微秒）
void sp_timer_delay(u32 us)
{
    u32 start=sp_timer_get();
    while(sp_timer_get()-start<us)
    {
    }
}

//定时器复位
void sp_timer_reset()
{
    timer_ext_count=0;
}
